from django.conf.urls import url
from django.conf.urls import url, include
#from django.path import path
from utility import views

urlpatterns = [
	url(r'^$', views.IndexView.as_view()),
	url(r'^inhibit$', views.InhibitView.as_view()),
	url(r'^appfind$', views.AppFindView.as_view()),
	]
    #url(r'(?P<pk>[0-9]*)/detail/$', views.DetailView.as_view()),
    #url(r'(?P<question_id>[0-9]*)/vote$', views.vote, name='vote'),
    #url(r'(?P<pk>[0-9])/results/$', views.ResultsView.as_view(), name='results'),