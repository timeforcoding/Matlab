# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.views import generic
from django.views.generic import TemplateView

# Create your views here.
class IndexView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)
class InhibitView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'inhibit.html', context=None)

class AppFindView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'appfind.html', context=None)        