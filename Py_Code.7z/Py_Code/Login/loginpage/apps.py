from django.apps import AppConfig


class LoginpageConfig(AppConfig):
    name = 'loginpage'
