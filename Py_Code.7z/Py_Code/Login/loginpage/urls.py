from django.conf.urls import url
from loginpage import views

urlpatterns = [
    url(r'^$', views.HomePageView.as_view()),
    url(r'^submitForm/$', views.loginConfirm)
]
