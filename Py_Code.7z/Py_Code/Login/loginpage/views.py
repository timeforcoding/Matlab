from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.views.generic import TemplateView
from .models import Employee
from .loginForms import nameForm

# Create your views here.

class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)

def loginConfirm(request):
    if request.method == 'POST':
        form = nameForm(request.POST)
        if form.is_valid():
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            login_obj = Employee(first_name = first_name, last_name = last_name)
            login_obj.save()
            obj = {'first_name': first_name}
            obj["last_name"] = last_name
            # return HttpResponseRedirect('/thanks/')
        # return render(request, 'name.html', {'form': form})
        return render(request,'success.html',obj)