import subprocess
import os
import sys
import select
command="C:\Program Files (x86)\PuTTY\plink.exe -ssh -pw Nov@2017 banuso02@unxs0612.ghanp.kfplc.com"
sp = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
response=sp.stdin.write("sudo su - iibadmin\n")
sp.stdin.write("pwd\n")
#sp.stdout.write("\n")
#print(response)
#fullFile=sp.stdout.read(1)
line=''
while sp.poll() is None:
  #print sp.poll()
  #if sp.poll() is None:
#	break
  line = sp.stdout.readline()
  #line = line.replcae("\n","")
  if line == '' or line is None or sp.poll() is not None or line == "END":
    print("Sou")
    break    
  else:
    print(line)
    sp.stdout.flush()
    print("Sou1")
