from django.conf.urls import url
from django.conf.urls import url, include
#from django.path import path
from OperationsHome import views

urlpatterns = [
	url(r'^$', views.IndexView.as_view()),
    url(r'(?P<pk>[0-9]*)/detail/$', views.DetailView.as_view()),
    url(r'(?P<question_id>[0-9]*)/vote$', views.vote, name='vote'),
    url(r'(?P<pk>[0-9])/results/$', views.ResultsView.as_view(), name='results'),
    #url(r'^1/$', views.DetailView.as_view()),
    #url(r'^2/$', views.DetailView.as_view()),
    #url(r'^3/$', views.DetailView.as_view()),

    #path('', views.IndexView.as_view(), name='index'),
    #path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    #path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    #path('<int:question_id>/vote/', views.vote, name='vote'),
]