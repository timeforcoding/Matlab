import os

print("hey")